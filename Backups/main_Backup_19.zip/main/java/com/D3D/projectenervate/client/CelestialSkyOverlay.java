package com.D3D.projectenervate.client;

import com.D3D.projectenervate.ProjectEnervate;
import com.D3D.projectenervate.menu.CelestialMappingMenu;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.util.List;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public final class CelestialSkyOverlay {
    private static final ResourceLocation STAR_TEXTURE = ResourceLocation.fromNamespaceAndPath(
            ProjectEnervate.MOD_ID,
            "textures/gui/celestial_star.png"
    );

    private static final int STAR_FRAME_SIZE = 16;
    private static final int STAR_FRAME_COUNT = 6;
    private static final int STAR_TEXTURE_WIDTH = STAR_FRAME_SIZE * STAR_FRAME_COUNT;
    private static final int STAR_TEXTURE_HEIGHT = STAR_FRAME_SIZE;
    private static final int STAR_FRAME_TICKS = 7;

    private static final double MIN_MULTIPLIER = 0.1D;
    private static final double MAX_MULTIPLIER = 2.0D;

    /*
     * These are sky-sphere units, not GUI pixels.
     * The star is rendered on an artificial sky shell around the camera, so camera translation causes no parallax.
     */
    private static final double SKY_DISTANCE = 100.0D;
    private static final double MIN_STAR_WORLD_SIZE = 1D;
    private static final double MAX_STAR_WORLD_SIZE = 5D;

    private CelestialSkyOverlay() {
    }

    public static void onRenderLevelStage(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_SKY) {
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();

        if (minecraft == null || minecraft.level == null || minecraft.player == null || minecraft.screen != null) {
            return;
        }

        float nightAlpha = getNightAlpha(minecraft.level.getDayTime());
        if (nightAlpha <= 0.0F) {
            return;
        }

        List<CelestialMappingMenu.CelestialBodyView> bodies = CelestialClientCourseState.getBodies();
        if (bodies.isEmpty()) {
            return;
        }

        PoseStack poseStack = event.getPoseStack();
        if (poseStack == null) {
            return;
        }

        long gameTime = minecraft.level.getGameTime();
        Camera camera = event.getCamera();
        if (camera == null) {
            return;
        }

        /*
         * RenderLevelStageEvent AFTER_SKY gives us a sky render slot, but the pose matrix used here is
         * not enough by itself to turn stable world-sky directions into camera-space coordinates.
         * If we submit raw world directions, the quad behaves like a HUD element and sticks to the view.
         *
         * Convert each sky-shell vertex from world-sky direction into the current camera coordinate system
         * by applying the inverse camera rotation. Translation is intentionally ignored: these are stars
         * on an infinite sky shell, not nearby world objects.
         */
        Quaternionf worldToCameraRotation = new Quaternionf(camera.rotation()).conjugate();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
        RenderSystem.setShaderTexture(0, STAR_TEXTURE);

        Matrix4f matrix = poseStack.last().pose();
        BufferBuilder buffer = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);

        for (int i = 0; i < bodies.size(); i++) {
            CelestialMappingMenu.CelestialBodyView body = bodies.get(i);
            SkyPosition position = skyPositionFor(body);
            Vec3 worldDirection = directionFromYawPitch(position.yaw(), position.pitch());

            /*
             * Build the star quad in stable world-sky coordinates first.
             * It is later rotated into camera space once per vertex.
             */
            Vec3 center = worldDirection.scale(SKY_DISTANCE);
            double halfSize = starWorldSizeForMultiplier(body.multiplier()) * 0.5D;

            Vec3 right = worldDirection.cross(new Vec3(0.0D, 1.0D, 0.0D));
            if (right.lengthSqr() < 0.0001D) {
                right = worldDirection.cross(new Vec3(1.0D, 0.0D, 0.0D));
            }
            right = right.normalize();
            Vec3 up = right.cross(worldDirection).normalize();

            Vec3 r = right.scale(halfSize);
            Vec3 u = up.scale(halfSize);

            Vec3 p0 = rotateIntoCameraSpace(center.subtract(r).subtract(u), worldToCameraRotation);
            Vec3 p1 = rotateIntoCameraSpace(center.add(r).subtract(u), worldToCameraRotation);
            Vec3 p2 = rotateIntoCameraSpace(center.add(r).add(u), worldToCameraRotation);
            Vec3 p3 = rotateIntoCameraSpace(center.subtract(r).add(u), worldToCameraRotation);

            int frame = frameFor(gameTime + i, STAR_FRAME_TICKS, STAR_FRAME_COUNT);
            float u0 = (float) (frame * STAR_FRAME_SIZE) / (float) STAR_TEXTURE_WIDTH;
            float u1 = (float) ((frame + 1) * STAR_FRAME_SIZE) / (float) STAR_TEXTURE_WIDTH;
            float v0 = 0.0F;
            float v1 = (float) STAR_FRAME_SIZE / (float) STAR_TEXTURE_HEIGHT;
            int alpha = Mth.clamp((int) (nightAlpha * 255.0F), 0, 255);

            addVertex(buffer, matrix, p0, u0, v1, alpha);
            addVertex(buffer, matrix, p1, u1, v1, alpha);
            addVertex(buffer, matrix, p2, u1, v0, alpha);
            addVertex(buffer, matrix, p3, u0, v0, alpha);
        }

        BufferUploader.drawWithShader(buffer.buildOrThrow());

        RenderSystem.depthMask(true);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.disableBlend();
    }


    private static Vec3 rotateIntoCameraSpace(Vec3 worldVector, Quaternionf worldToCameraRotation) {
        Vector3f transformed = new Vector3f((float) worldVector.x, (float) worldVector.y, (float) worldVector.z);
        transformed.rotate(worldToCameraRotation);
        return new Vec3(transformed.x(), transformed.y(), transformed.z());
    }

    private static void addVertex(BufferBuilder buffer, Matrix4f matrix, Vec3 pos, float u, float v, int alpha) {
        buffer.addVertex(matrix, (float) pos.x, (float) pos.y, (float) pos.z)
                .setUv(u, v)
                .setColor(255, 255, 255, alpha);
    }

    private static Vec3 directionFromYawPitch(double yawDegrees, double pitchDegrees) {
        double yaw = Math.toRadians(yawDegrees);
        double pitch = Math.toRadians(pitchDegrees);
        double horizontal = Math.cos(pitch);

        double x = -Math.sin(yaw) * horizontal;
        double y = -Math.sin(pitch);
        double z = Math.cos(yaw) * horizontal;

        return new Vec3(x, y, z).normalize();
    }

    private static float getNightAlpha(long dayTimeRaw) {
        long dayTime = Math.floorMod(dayTimeRaw, 24000L);

        if (dayTime < 12000L || dayTime > 24000L) {
            return 0.0F;
        }

        if (dayTime < 14000L) {
            return (dayTime - 12000L) / 2000.0F;
        }

        if (dayTime > 22000L) {
            return (24000L - dayTime) / 2000.0F;
        }

        return 1.0F;
    }

    private static int frameFor(long gameTime, int frameTicks, int frameCount) {
        if (frameCount <= 1) {
            return 0;
        }

        return (int) ((gameTime / Math.max(1, frameTicks)) % frameCount);
    }

    private static double starWorldSizeForMultiplier(double multiplier) {
        double normalized = (multiplier - MIN_MULTIPLIER) / (MAX_MULTIPLIER - MIN_MULTIPLIER);
        normalized = Mth.clamp(normalized, 0.0D, 1.0D);
        return Mth.lerp(normalized, MIN_STAR_WORLD_SIZE, MAX_STAR_WORLD_SIZE);
    }

    private static SkyPosition skyPositionFor(CelestialMappingMenu.CelestialBodyView body) {
        long seed = mix64(body.resourceId().hashCode() * 0x9E3779B97F4A7C15L ^ body.celestialName().hashCode());
        double yaw = unsignedUnit(seed) * 360.0D;

        /*
         * Negative pitch points above the horizon in Minecraft camera terms.
         * Keep stars in the upper night sky instead of near the horizon.
         */
        double pitch = -18.0D - unsignedUnit(mix64(seed ^ 0x534b595049544348L)) * 48.0D;
        return new SkyPosition(yaw, pitch);
    }

    private static double unsignedUnit(long value) {
        long positive = value >>> 1;
        return positive / (double) Long.MAX_VALUE;
    }

    private static long mix64(long value) {
        value = (value ^ (value >>> 30)) * 0xbf58476d1ce4e5b9L;
        value = (value ^ (value >>> 27)) * 0x94d049bb133111ebL;
        return value ^ (value >>> 31);
    }

    private record SkyPosition(double yaw, double pitch) {
    }
}
