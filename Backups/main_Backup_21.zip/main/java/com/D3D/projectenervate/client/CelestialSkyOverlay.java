package com.D3D.projectenervate.client;

import com.D3D.projectenervate.ProjectEnervate;
import com.D3D.projectenervate.menu.CelestialMappingMenu;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import java.util.List;
import java.util.Optional;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public final class CelestialSkyOverlay {
    private static final ResourceLocation STAR_TEXTURE = ResourceLocation.fromNamespaceAndPath(
            ProjectEnervate.MOD_ID,
            "textures/gui/celestial_star.png"
    );

    private static final double MIN_STAR_WORLD_SIZE = 1.5D;
    private static final double MID_STAR_WORLD_SIZE = 3D;
    private static final double MAX_STAR_WORLD_SIZE =10D;

    private static final int STAR_FRAME_SIZE = 16;
    private static final int STAR_FRAME_COUNT = 6;
    private static final int STAR_TEXTURE_WIDTH = STAR_FRAME_SIZE * STAR_FRAME_COUNT;
    private static final int STAR_TEXTURE_HEIGHT = STAR_FRAME_SIZE;
    private static final int STAR_FRAME_TICKS = 7;

    private static final double MIN_MULTIPLIER = 0.1D;
    private static final double MAX_MULTIPLIER = 2.0D;
    private static final double MID_MULTIPLIER = 1.0D;


    /*
     * These are sky-sphere units, not GUI pixels.
     * The star is rendered on an artificial sky shell around the camera, so camera translation causes no parallax.
     */
    private static final double SKY_DISTANCE = 100.0D;

    private static final double MIN_MOON_OFFSET_DEGREES = 10.0D;
    private static final double MAX_MOON_OFFSET_DEGREES = 78.0D;

    private static final double VANILLA_SPYGLASS_FOV_MULTIPLIER = 0.1D;
    private static final double SCOPED_SCREEN_MARGIN = 1.06D;

    private static final Vec3 BASE_MOON_DIRECTION = new Vec3(0.0D, -1.0D, 0.0D);
    private static final Vec3 BASE_MOON_TANGENT_RIGHT = new Vec3(1.0D, 0.0D, 0.0D);
    private static final Vec3 BASE_MOON_TANGENT_UP = new Vec3(0.0D, 0.0D, 1.0D);
    private static final double VANILLA_SKY_YAW_DEGREES = -90.0D;

    private CelestialSkyOverlay() {
    }

    public record ScopedStarHit(
            CelestialMappingMenu.CelestialBodyView body,
            int x,
            int y,
            double angleDegrees
    ) {
    }

    public static Optional<ScopedStarHit> findScopedStarHit(Minecraft minecraft, Camera camera, int guiWidth, int guiHeight, float partialTick) {
        if (minecraft == null || minecraft.level == null || camera == null || guiWidth <= 0 || guiHeight <= 0) {
            return Optional.empty();
        }

        if (getNightAlpha(minecraft.level.getDayTime()) <= 0.0F) {
            return Optional.empty();
        }

        List<CelestialMappingMenu.CelestialBodyView> bodies = CelestialClientCourseState.getBodies();
        if (bodies.isEmpty()) {
            return Optional.empty();
        }

        Vec3 look = fromVector3f(camera.getLookVector()).normalize();
        Vec3 right = fromVector3f(camera.getLeftVector()).normalize().scale(-1.0D);
        Vec3 up = fromVector3f(camera.getUpVector()).normalize();

        double verticalTan = Math.tan(Math.toRadians(scopedVerticalFovDegrees(minecraft)) * 0.5D);
        double horizontalTan = verticalTan * ((double) guiWidth / (double) guiHeight);
        double celestialAngleDegrees = minecraft.level.getTimeOfDay(partialTick) * 360.0D;
        long skySeed = CelestialClientCourseState.getWorldSeed();

        ScopedStarHit best = null;
        double bestAngle = Double.MAX_VALUE;

        for (CelestialMappingMenu.CelestialBodyView body : bodies) {
            Vec3 worldDirection = moonRelativeSkyDirectionFor(body, skySeed, celestialAngleDegrees);
            double forward = worldDirection.dot(look);
            if (forward <= 0.001D) {
                continue;
            }

            double ndcX = worldDirection.dot(right) / (forward * horizontalTan);
            double ndcY = worldDirection.dot(up) / (forward * verticalTan);

            if (Math.abs(ndcX) > SCOPED_SCREEN_MARGIN || Math.abs(ndcY) > SCOPED_SCREEN_MARGIN) {
                continue;
            }

            double angleDegrees = Math.toDegrees(Math.acos(clamp(forward, -1.0D, 1.0D)));
            if (angleDegrees >= bestAngle) {
                continue;
            }

            double starAngularRadius = (starWorldSizeForMultiplier(body.multiplier()) * 0.5D) / SKY_DISTANCE;
            int starPixelRadius = Math.max(6, (int) Math.ceil((starAngularRadius / verticalTan) * guiHeight * 0.5D));
            int x = (int) Math.round((guiWidth * 0.5D) + ndcX * guiWidth * 0.5D);
            int y = (int) Math.round((guiHeight * 0.5D) - ndcY * guiHeight * 0.5D + starPixelRadius + 4);

            best = new ScopedStarHit(body, x, y, angleDegrees);
            bestAngle = angleDegrees;
        }

        return Optional.ofNullable(best);
    }

    public static void onRenderLevelStage(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_SKY) {
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();

        /*
         * Do not check minecraft.screen here.
         * The chat window and inventory are screens, but the world is still rendered behind them.
         * Skipping when a screen is open makes the stars pop out exactly when chat opens.
         */
        if (minecraft == null || minecraft.level == null || minecraft.player == null) {
            return;
        }

        float nightAlpha = getNightAlpha(minecraft.level.getDayTime());
        if (nightAlpha <= 0.0F) {
            return;
        }

        List<CelestialMappingMenu.CelestialBodyView> bodies = CelestialClientCourseState.getBodies();
        if (bodies.isEmpty()) {
            return;
        }

        PoseStack poseStack = event.getPoseStack();
        if (poseStack == null) {
            return;
        }

        long gameTime = minecraft.level.getGameTime();
        Camera camera = event.getCamera();
        if (camera == null) {
            return;
        }

        /*
         * RenderLevelStageEvent AFTER_SKY gives us a sky render slot. The star directions are stable
         * world-sky directions, then rotated into camera space manually. Translation is intentionally
         * ignored because the stars sit on an infinite sky shell.
         */
        Quaternionf worldToCameraRotation = new Quaternionf(camera.rotation()).conjugate();
        float partialTick = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        double celestialAngleDegrees = minecraft.level.getTimeOfDay(partialTick) * 360.0D;
        long skySeed = CelestialClientCourseState.getWorldSeed();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
        RenderSystem.setShaderTexture(0, STAR_TEXTURE);

        Matrix4f matrix = poseStack.last().pose();
        BufferBuilder buffer = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX_COLOR);

        for (int i = 0; i < bodies.size(); i++) {
            CelestialMappingMenu.CelestialBodyView body = bodies.get(i);
            Vec3 worldDirection = moonRelativeSkyDirectionFor(body, skySeed, celestialAngleDegrees);

            Vec3 center = worldDirection.scale(SKY_DISTANCE);
            double halfSize = starWorldSizeForMultiplier(body.multiplier()) * 0.5D;

            Vec3 right = worldDirection.cross(new Vec3(0.0D, 1.0D, 0.0D));
            if (right.lengthSqr() < 0.0001D) {
                right = worldDirection.cross(new Vec3(1.0D, 0.0D, 0.0D));
            }
            right = right.normalize();
            Vec3 up = right.cross(worldDirection).normalize();

            Vec3 r = right.scale(halfSize);
            Vec3 u = up.scale(halfSize);

            Vec3 p0 = rotateIntoCameraSpace(center.subtract(r).subtract(u), worldToCameraRotation);
            Vec3 p1 = rotateIntoCameraSpace(center.add(r).subtract(u), worldToCameraRotation);
            Vec3 p2 = rotateIntoCameraSpace(center.add(r).add(u), worldToCameraRotation);
            Vec3 p3 = rotateIntoCameraSpace(center.subtract(r).add(u), worldToCameraRotation);

            int frame = frameFor(gameTime + i, STAR_FRAME_TICKS, STAR_FRAME_COUNT);
            float u0 = (float) (frame * STAR_FRAME_SIZE) / (float) STAR_TEXTURE_WIDTH;
            float u1 = (float) ((frame + 1) * STAR_FRAME_SIZE) / (float) STAR_TEXTURE_WIDTH;
            float v0 = 0.0F;
            float v1 = (float) STAR_FRAME_SIZE / (float) STAR_TEXTURE_HEIGHT;
            int alpha = Mth.clamp((int) (nightAlpha * 255.0F), 0, 255);

            addVertex(buffer, matrix, p0, u0, v1, alpha);
            addVertex(buffer, matrix, p1, u1, v1, alpha);
            addVertex(buffer, matrix, p2, u1, v0, alpha);
            addVertex(buffer, matrix, p3, u0, v0, alpha);
        }

        BufferUploader.drawWithShader(buffer.buildOrThrow());

        RenderSystem.depthMask(true);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.disableBlend();
    }

    private static Vec3 rotateIntoCameraSpace(Vec3 worldVector, Quaternionf worldToCameraRotation) {
        Vector3f transformed = new Vector3f((float) worldVector.x, (float) worldVector.y, (float) worldVector.z);
        transformed.rotate(worldToCameraRotation);
        return new Vec3(transformed.x(), transformed.y(), transformed.z());
    }

    private static Vec3 fromVector3f(Vector3f vector) {
        return new Vec3(vector.x(), vector.y(), vector.z());
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    private static double scopedVerticalFovDegrees(Minecraft minecraft) {
        if (minecraft == null || minecraft.options == null || minecraft.options.fov() == null) {
            return 7.0D;
        }

        return clamp(minecraft.options.fov().get() * VANILLA_SPYGLASS_FOV_MULTIPLIER, 3.0D, 11.0D);
    }

    private static void addVertex(BufferBuilder buffer, Matrix4f matrix, Vec3 pos, float u, float v, int alpha) {
        buffer.addVertex(matrix, (float) pos.x, (float) pos.y, (float) pos.z)
                .setUv(u, v)
                .setColor(255, 255, 255, alpha);
    }

    private static float getNightAlpha(long dayTimeRaw) {
        long dayTime = Math.floorMod(dayTimeRaw, 24000L);

        if (dayTime < 12000L || dayTime > 24000L) {
            return 0.0F;
        }

        if (dayTime < 14000L) {
            return (dayTime - 12000L) / 2000.0F;
        }

        if (dayTime > 22000L) {
            return (24000L - dayTime) / 2000.0F;
        }

        return 1.0F;
    }

    private static int frameFor(long gameTime, int frameTicks, int frameCount) {
        if (frameCount <= 1) {
            return 0;
        }

        return (int) ((gameTime / Math.max(1, frameTicks)) % frameCount);
    }

    private static double starWorldSizeForMultiplier(double multiplier) {
        double normalized = (multiplier - MIN_MULTIPLIER) / (MAX_MULTIPLIER - MIN_MULTIPLIER);
        normalized = Mth.clamp(normalized, 0.0D, 1.0D);

        double normalizedMid = (MID_MULTIPLIER - MIN_MULTIPLIER) / (MAX_MULTIPLIER - MIN_MULTIPLIER);
        normalizedMid = Mth.clamp(normalizedMid, 0.000001D, 0.999999D);

        double midSizeNormalized = (MID_STAR_WORLD_SIZE - MIN_STAR_WORLD_SIZE) / (MAX_STAR_WORLD_SIZE - MIN_STAR_WORLD_SIZE);
        midSizeNormalized = Mth.clamp(midSizeNormalized, 0.000001D, 0.999999D);

        double curvePower = Math.log(midSizeNormalized) / Math.log(normalizedMid);
        double curved = Math.pow(normalized, curvePower);

        return Mth.lerp(curved, MIN_STAR_WORLD_SIZE, MAX_STAR_WORLD_SIZE);
    }

    private static Vec3 moonRelativeSkyDirectionFor(CelestialMappingMenu.CelestialBodyView body, long skySeed, double celestialAngleDegrees) {
        long seed = starSeedFor(body, skySeed);
        double azimuth = unsignedUnit(seed) * Math.PI * 2.0D;
        double moonOffset = Math.toRadians(MIN_MOON_OFFSET_DEGREES
                + unsignedUnit(mix64(seed ^ 0x4d4f4f4e5f4f4646L)) * (MAX_MOON_OFFSET_DEGREES - MIN_MOON_OFFSET_DEGREES));

        /*
         * Build the star inside the moon-side hemisphere before applying vanilla's celestial rotation.
         * Dot(baseDirection, BASE_MOON_DIRECTION) is always positive because moonOffset stays below 90 degrees,
         * so the generated star starts on the moon/night side and never on the sun/day side.
         */
        double moonWeight = Math.cos(moonOffset);
        double tangentWeight = Math.sin(moonOffset);
        Vec3 baseDirection = BASE_MOON_DIRECTION.scale(moonWeight)
                .add(BASE_MOON_TANGENT_RIGHT.scale(Math.cos(azimuth) * tangentWeight))
                .add(BASE_MOON_TANGENT_UP.scale(Math.sin(azimuth) * tangentWeight))
                .normalize();

        return applyVanillaCelestialRotation(baseDirection, celestialAngleDegrees).normalize();
    }

    private static Vec3 applyVanillaCelestialRotation(Vec3 vector, double celestialAngleDegrees) {
        /*
         * Vanilla renders sun and moon with this transform order:
         *   Y axis -90 degrees, then X axis timeOfDay * 360 degrees.
         * For a vertex this means the direction is rotated around X first, then around Y.
         * The previous version only applied the X rotation, which made the stars orbit on a
         * sky great-circle about 90 degrees away from the moon's visible path.
         */
        return rotateAroundY(rotateAroundX(vector, celestialAngleDegrees), VANILLA_SKY_YAW_DEGREES);
    }

    private static Vec3 rotateAroundX(Vec3 vector, double degrees) {
        double radians = Math.toRadians(degrees);
        double cos = Math.cos(radians);
        double sin = Math.sin(radians);
        double y = vector.y * cos - vector.z * sin;
        double z = vector.y * sin + vector.z * cos;
        return new Vec3(vector.x, y, z);
    }

    private static Vec3 rotateAroundY(Vec3 vector, double degrees) {
        double radians = Math.toRadians(degrees);
        double cos = Math.cos(radians);
        double sin = Math.sin(radians);
        double x = vector.x * cos + vector.z * sin;
        double z = -vector.x * sin + vector.z * cos;
        return new Vec3(x, vector.y, z);
    }

    private static long starSeedFor(CelestialMappingMenu.CelestialBodyView body, long skySeed) {
        long value = skySeed;
        value ^= ((long) body.resourceId().hashCode()) * 0x9E3779B97F4A7C15L;
        value ^= Long.rotateLeft((long) body.celestialName().hashCode(), 32);
        return mix64(value);
    }

    private static double unsignedUnit(long value) {
        long positive = value >>> 1;
        return positive / (double) Long.MAX_VALUE;
    }

    private static long mix64(long value) {
        value = (value ^ (value >>> 30)) * 0xbf58476d1ce4e5b9L;
        value = (value ^ (value >>> 27)) * 0x94d049bb133111ebL;
        return value ^ (value >>> 31);
    }
}
