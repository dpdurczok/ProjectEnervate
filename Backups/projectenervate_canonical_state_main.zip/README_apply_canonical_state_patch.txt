ProjectEnervate canonical state patch
=====================================

What this patch does
--------------------
- Stops writing source-specific stack data such as crafting, trade, block_drop, and transmutation.
- Uses only canonical economic states on ItemStacks:
  - projectenervate_state = verified
  - projectenervate_state = zero plus projectenervate_adaptive_emc = 0.00000000
  - projectenervate_state = adaptive plus projectenervate_adaptive_emc = <per item value>
- Keeps reading and removing the old legacy projectenervate_source tag.
- Adds a global ItemStack compatibility mixin so ProjectEnervate's own metadata does not block stacking.
- Recomputes weighted EMC after modded ItemStackHandler and InvWrapper inserts.

Install option A, git patch
---------------------------
From your project root:

git apply .\projectenervate_canonical_state.patch
.\gradlew.bat build

Install option B, replacement src/main
--------------------------------------
1. Extract projectenervate_canonical_state_main.zip.
2. Copy the extracted main folder over your project's src/main folder.
3. Run:

.\gradlew.bat build

Important files changed
-----------------------
src/main/java/com/D3D/projectenervate/emc/ProjectEnervateSourceHelper.java
src/main/java/com/D3D/projectenervate/emc/AdaptiveEmcHelper.java
src/main/java/com/D3D/projectenervate/emc/KnownSourceEvents.java
src/main/java/com/D3D/projectenervate/mixin/ItemStackProjectEnervateCompatibilityMixin.java
src/main/java/com/D3D/projectenervate/mixin/ItemStackHandlerUnknownSourceMixin.java
src/main/java/com/D3D/projectenervate/mixin/InvWrapperUnknownSourceMixin.java
src/main/java/com/D3D/projectenervate/mixin/InventoryMixin.java
src/main/java/com/D3D/projectenervate/mixin/ItemEntityPickupUnknownSourceMixin.java
src/main/java/com/D3D/projectenervate/mixin/ResultSlotKnownSourceMixin.java
src/main/java/com/D3D/projectenervate/mixin/TransmutationMenuKnownSourceMixin.java
src/main/java/com/D3D/projectenervate/mixin/TransmutationQuickMoveKnownSourceMixin.java
src/main/resources/projectenervate.mixins.json

Build note
----------
I could not run Gradle from the uploaded zip because the zip only contained src/main content, not the Gradle wrapper or dependency cache.
