package com.D3D.projectenervate.client;

import com.D3D.projectenervate.registry.ProjectEnervateMenus;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

public final class ProjectEnervateClientEvents {
    private ProjectEnervateClientEvents() {
    }

    public static void registerScreens(RegisterMenuScreensEvent event) {
        event.register(ProjectEnervateMenus.EMC_ASSIGNMENT_STATION.get(), EmcAssignmentScreen::new);
    }
}
