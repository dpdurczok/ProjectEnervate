package com.D3D.projectenervate.client;

import com.D3D.projectenervate.ProjectEnervate;
import com.D3D.projectenervate.menu.CelestialMappingMenu;
import com.mojang.blaze3d.systems.RenderSystem;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;

public class CelestialMappingScreen extends AbstractContainerScreen<CelestialMappingMenu> {
    private static final ResourceLocation BACKGROUND_TEXTURE = ResourceLocation.fromNamespaceAndPath(
            ProjectEnervate.MOD_ID,
            "textures/gui/celestial_mapping_bg.png"
    );
    private static final ResourceLocation STAR_TEXTURE = ResourceLocation.fromNamespaceAndPath(
            ProjectEnervate.MOD_ID,
            "textures/gui/celestial_star.png"
    );

    private static final DecimalFormat DECIMAL = new DecimalFormat("0.00");
    private static final int TEXTURE_WIDTH = 320;
    private static final int TEXTURE_HEIGHT = 260;
    private static final int STAR_SIZE = 16;
    private static final int STAR_TEXTURE_WIDTH = 16;
    private static final int STAR_TEXTURE_HEIGHT = 16;
    private static final int HOVER_RADIUS = 10;
    private static final double MIN_MULTIPLIER = 0.1D;
    private static final double MAX_MULTIPLIER = 2.0D;
    private static final double MIN_RADIUS = 31.0D;
    private static final double MAX_RADIUS = 112.0D;
    private static final double LINEAR_ORBIT_SPEED_PIXELS_PER_TICK = 0.002D;

    private final List<RenderedBody> renderedBodies = new ArrayList<>();

    public CelestialMappingScreen(CelestialMappingMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
        imageWidth = TEXTURE_WIDTH;
        imageHeight = TEXTURE_HEIGHT;
        titleLabelX = 10000;
        titleLabelY = 10000;
        inventoryLabelY = 10000;
    }

    @Override
    protected void init() {
        super.init();
        titleLabelX = 10000;
        titleLabelY = 10000;
        inventoryLabelY = 10000;
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(guiGraphics, mouseX, mouseY, partialTick);
        super.render(guiGraphics, mouseX, mouseY, partialTick);
        renderHoveredTooltip(guiGraphics, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        renderedBodies.clear();

        int x = leftPos;
        int y = topPos;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        guiGraphics.blit(BACKGROUND_TEXTURE, x, y, 0, 0, imageWidth, imageHeight, TEXTURE_WIDTH, TEXTURE_HEIGHT);

        double centerX = x + imageWidth / 2.0D;
        double centerY = y + imageHeight / 2.0D;
        List<CelestialMappingMenu.CelestialBodyView> bodies = menu.getBodies();

        long gameTime = minecraft == null || minecraft.level == null ? 0L : minecraft.level.getGameTime();
        double orbitTime = gameTime + partialTick;

        for (int i = 0; i < bodies.size(); i++) {
            CelestialMappingMenu.CelestialBodyView body = bodies.get(i);
            double radius = radiusForMultiplier(body.multiplier(), i);
            double baseAngle = ((Math.PI * 2.0D) / Math.max(1, bodies.size())) * i;

            // Constant linear speed: outer stars use lower angular speed, inner stars use higher angular speed.
            double angularSpeed = LINEAR_ORBIT_SPEED_PIXELS_PER_TICK / Math.max(1.0D, radius);
            double angle = baseAngle + orbitTime * angularSpeed;

            double bodyX = centerX + Math.cos(angle) * radius;
            double bodyY = centerY + Math.sin(angle) * radius;
            double starX = bodyX - STAR_SIZE / 2.0D;
            double starY = bodyY - STAR_SIZE / 2.0D;

            drawStar(guiGraphics, starX, starY);
            renderedBodies.add(new RenderedBody(body, bodyX, bodyY));
        }

        RenderSystem.disableBlend();
    }

    private void drawStar(GuiGraphics guiGraphics, double x, double y) {
        guiGraphics.pose().pushPose();
        guiGraphics.pose().translate((float) x, (float) y, 0.0F);
        guiGraphics.blit(
                STAR_TEXTURE,
                0,
                0,
                0,
                0,
                STAR_SIZE,
                STAR_SIZE,
                STAR_TEXTURE_WIDTH,
                STAR_TEXTURE_HEIGHT
        );
        guiGraphics.pose().popPose();
    }

    @Override
    protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
        // Intentionally blank. This screen is visual-only until a star is hovered.
    }

    private double radiusForMultiplier(double multiplier, int index) {
        double normalized = (multiplier - MIN_MULTIPLIER) / (MAX_MULTIPLIER - MIN_MULTIPLIER);
        normalized = Mth.clamp(normalized, 0.0D, 1.0D);

        // Higher multiplier means closer to center. Lower multiplier means farther from center.
        double radius = Mth.lerp(1.0D - normalized, MIN_RADIUS, MAX_RADIUS);

        // Small deterministic lane offset keeps stars with almost identical values from sitting exactly on top of each other.
        double laneOffset = ((index % 3) - 1) * 3.0D;
        return Mth.clamp(radius + laneOffset, MIN_RADIUS, MAX_RADIUS);
    }

    private void renderHoveredTooltip(GuiGraphics guiGraphics, int mouseX, int mouseY) {
        for (RenderedBody rendered : renderedBodies) {
            double dx = mouseX - rendered.x();
            double dy = mouseY - rendered.y();

            if (dx * dx + dy * dy <= HOVER_RADIUS * HOVER_RADIUS) {
                List<FormattedCharSequence> tooltip = List.of(
                        Component.literal(rendered.body().celestialName()).getVisualOrderText(),
                        Component.literal("x" + DECIMAL.format(rendered.body().multiplier())).getVisualOrderText()
                );
                guiGraphics.renderTooltip(font, tooltip, mouseX, mouseY);
                return;
            }
        }
    }

    private record RenderedBody(
            CelestialMappingMenu.CelestialBodyView body,
            double x,
            double y
    ) {
    }
}
